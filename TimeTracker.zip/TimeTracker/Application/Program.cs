﻿using Business;
using Business.BusinessObjects;
using Business.Services;
using DataContracts;
using DataContracts.Entities;
using DataContracts.Entities.Enumerations;
using Repositories.Xml;

var userServices = new UserServices();

var user = userServices.GetUserData(1);


//Удалить ссылку на xml
//хуйня на чтение
var rx = new RepXml<User>();
var a =rx.GetAll();

foreach (var user1 in a)
{
    Console.WriteLine($"{user1.FullName}");
}
//хуйня на инсерт
var a2 = Stubs.Users.First();
rx.Insert(a2);


//user.SubmittedTimeChanged += OnSubmitteddTimeChanged;

//var activeUsers = userServices.GetUsersForProject(1);
//foreach (var activeUser in activeUsers)
//{
//    Console.WriteLine(activeUser.User.FullName);
//}

//void OnSubmitteddTimeChanged(int hours)
//{
//    Console.WriteLine($"Общая сумма часов: {hours}");
//}

