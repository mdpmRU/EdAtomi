﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contracts;
using DataContracts.Entities;

namespace Solution
{
    internal class Mapper : IUserRepository
    {
        public IEnumerable<User> GetAll()
        {
            throw new NotImplementedException();
        }

        public void Insert(List<User> obj)
        {
            throw new NotImplementedException();
        }
    }
}
