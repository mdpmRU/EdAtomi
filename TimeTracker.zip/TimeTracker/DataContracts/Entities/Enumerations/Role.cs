﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataContracts.Entities.Enumerations
{
    public enum Role
    {
        User,
        Leader,
        Admin
    }
}
